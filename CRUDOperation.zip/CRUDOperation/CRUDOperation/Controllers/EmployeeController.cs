﻿using CRUDOperation.Data;
using CRUDOperation.Models;
using CRUDOperation.Models.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDOperation.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly MVC_DB_Context mvcDB_Context;

        public EmployeeController(MVC_DB_Context mvcDB_Context)
        {
            this.mvcDB_Context = mvcDB_Context;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
           var Employees =  await mvcDB_Context.Engineer.ToListAsync();
            return View(Employees);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddEmployeeView addRequest) 
        {
            var employee = new Employee()
            {
                Id = Guid.NewGuid(),
                Name = addRequest.Name,
                Email = addRequest.Email,
                MobNo = addRequest.MobNo,
                Department = addRequest.Department,
                Salary = addRequest.Salary,
                DOB = addRequest.DOB,
            };

            await mvcDB_Context.Engineer.AddAsync(employee);
            await mvcDB_Context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> View(Guid id)
        {
			var Employee = await mvcDB_Context.Engineer.FirstOrDefaultAsync(x => x.Id == id);

            if (Employee != null)
            {
                var ViewModel = new UpdateView()
                {
                   
                    Name = Employee.Name,
                    Email = Employee.Email,
                    MobNo = Employee.MobNo,
                    Department = Employee.Department,
                    Salary = Employee.Salary,
                    DOB = Employee.DOB,
                };
                return await Task.Run(() =>View("View",ViewModel));

            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> View(UpdateView model)
        {
            var Employee = await mvcDB_Context.Engineer.FindAsync(model.Id);
            {
                if (Employee != null)
                {
                    Employee.Id = model.Id;
                    Employee.Name = model.Name;
                    Employee.Email = model.Email;
                    Employee.MobNo = model.MobNo;
                    Employee.Department = model.Department;
                    Employee.Salary = model.Salary;
                    Employee.DOB = model.DOB;

                    await mvcDB_Context.SaveChangesAsync();

                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index");
            }
        }

        public async Task<IActionResult> Delete(UpdateView model)
        {
            var Employee = await mvcDB_Context.Engineer.FindAsync(model.Id);

            if (Employee != null)
            {
                mvcDB_Context.Engineer.Remove(Employee);
                await mvcDB_Context.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }

    }
}
