﻿using CRUDOperation.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace CRUDOperation.Data
{
    public class MVC_DB_Context : DbContext
    {
        public MVC_DB_Context(DbContextOptions options) : base(options)
        {
        }


        public DbSet<Employee> Engineer { get; set; }
    }
}
